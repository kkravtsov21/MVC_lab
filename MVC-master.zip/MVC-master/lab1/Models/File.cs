using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace lab1.Models

{
    public class File 
    { 
        public string FileName { get; set; }
    }
}    

